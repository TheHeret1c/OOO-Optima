﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delivery.Classes
{
    class Helper
    {
        public static Model.CourierDBEntities DB { get; set; }

        public static Model.User user { get; set; }
    }
}
